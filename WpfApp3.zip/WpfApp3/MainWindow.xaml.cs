﻿using Microsoft.Win32;
using SuperSimpleTcp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using WpfApp3.Models;


namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SimpleTcpServer server;
        NTRUEncrypt ntru = new NTRUEncrypt();

        SerpentCipher serpent= new SerpentCipher();
        byte[] serpentKey=SerpentCipher.RandomizeKey();

        public MainWindow()
        {
            InitializeComponent();
        }


        async void btnStart_Click(object sender, RoutedEventArgs e)
        {
            server = new SimpleTcpServer("127.0.0.1:9000");
            ntru.generate_key();

            server.Events.ClientConnected += ClientConnected;
            server.Events.ClientDisconnected += ClientDisconnected;
            server.Events.DataReceived += DataReceived;
            server.Start();
            btnStart.IsEnabled = false;
        }


        void ClientConnected(object sender, ConnectionEventArgs e)
        {

            String str = $"[{e.IpPort}] client connected\n";
            Dispatcher.Invoke(() => MyTextBlock.Text += str);


            int buffersize = 128;
            byte[] header = null;

            header = new byte[buffersize];
            string headerStr = "recieving public key:" + "recieving public key" + "\r\n";
            Array.Copy(Encoding.ASCII.GetBytes(headerStr), header, Encoding.ASCII.GetBytes(headerStr).Length);

            byte[] data = ntru.get_public_key();

            byte[] result = new byte[header.Length + data.Length];
            header.CopyTo(result, 0);
            data.CopyTo(result, header.Length);


            server.Send(e.IpPort, result);
        }

        void ClientDisconnected(object sender, ConnectionEventArgs e)
        {
            String str = $"[{e.IpPort}] client disconnected: {e.Reason}\n";
            Dispatcher.Invoke(() => MyTextBlock.Text += str);

        }

        void DataReceived(object sender, DataReceivedEventArgs e)
        {
            byte[] msg = e.Data.Take(128).ToArray();


            byte[] data = e.Data.Skip(128).ToArray();

            String str = $"[{e.IpPort}]: {Encoding.UTF8.GetString(msg, 0, msg.Length)}\n";

            Dispatcher.Invoke(() => MyTextBlock.Text += str);


            string msgStr = Encoding.ASCII.GetString(msg);





            string[] splitted = msgStr.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            Dictionary<string, string> headers = new Dictionary<string, string>();
            foreach (string s in splitted)
            {
                if (s.Contains(":"))
                {
                    headers.Add(s.Substring(0, s.IndexOf(":")), s.Substring(s.IndexOf(":") + 1));
                }

            }

            if (headers.ContainsKey("asking for serpent key"))
            {
                byte[] clientsKey = ntru.decryption(data);

                byte[] newData = serpent.Encrypt(serpentKey, clientsKey, 32, Mode.Standard, EncryptionMode.CBC);

                int buffersize = 128;
                byte[] header = null;

                header = new byte[buffersize];
                string headerStr = "recieving serpent key:" + " " + "\r\n";
                Array.Copy(Encoding.ASCII.GetBytes(headerStr), header, Encoding.ASCII.GetBytes(headerStr).Length);


                byte[] result = new byte[header.Length + newData.Length];
                header.CopyTo(result, 0);
                newData.CopyTo(result, header.Length);


                server.Send(e.IpPort, result);


               
            }
            else
            {
                SendFile(e.Data.ToArray(), e.IpPort);
            }



        }

        void SendFile(byte[] data, string ipPort)
        {
            foreach (string client in server.GetClients() )
            {
                if(ipPort != client)
                    server.Send(client, data);
            }

        }

    }
}

