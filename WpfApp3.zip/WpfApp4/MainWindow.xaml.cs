﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SuperSimpleTcp;

using System.Net.Sockets;
using System.Net;
using System.Threading;
using System.IO;
using Microsoft.Win32;
using System.Net.Http;
using System.Windows.Markup;
using System.IO.Pipes;
using System.Text.RegularExpressions;
using System.Reflection.PortableExecutable;
using System.DirectoryServices.ActiveDirectory;
using WpfApp4.Models;
using System.Collections;


namespace WpfApp4
{
    public partial class MainWindow : Window
    {
        SimpleTcpClient client;
        byte[] ntruKey;
        byte[] serpentKey = SerpentCipher.RandomizeKey();

        NTRUEncrypt ntru = new();
        SerpentCipher serpent = new();
        

        public MainWindow()
        {
            InitializeComponent();
            client = new SimpleTcpClient(textBox.Text);

        }


        async void btnSendFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                int buffersize = 128;

                byte[] header = null;


                FileStream fs = new FileStream(openFileDialog.FileName, FileMode.Open);
                byte[] data = new byte[fs.Length];
                fs.Read(data);


                string headerStr = "Content-length:" + fs.Length.ToString() + "\r\nFilename:" + System.IO.Path.GetFileName(openFileDialog.FileName) + "\r\n";
                header = new byte[buffersize];
                Array.Copy(Encoding.ASCII.GetBytes(headerStr), header, Encoding.ASCII.GetBytes(headerStr).Length);


                

                data = serpent.Encrypt(data, serpentKey, 32, Mode.Standard, EncryptionMode.CBC);

                byte[] result = new byte[header.Length + data.Length];
                header.CopyTo(result, 0);
                data.CopyTo(result, header.Length);


                
                client.Send(result);                
                fs.Close();

            }

        }


        async void btnConect_Click(object sender, RoutedEventArgs e)
        {


            
            client.Events.Connected += Connected;

            client.Events.Disconnected += Disconnected;
            client.Events.DataReceived += DataReceived;

            client.Connect();

        }



        void Connected(object sender, ConnectionEventArgs e)
        {
            String str = $"Server {e.IpPort} connected\n";
            Dispatcher.Invoke(() => MyTextBlock.Text += str);
        }

        void Disconnected(object sender, ConnectionEventArgs e)
        {
            String str = $"Server {e.IpPort} disconnected\n";
            Dispatcher.Invoke(() => MyTextBlock.Text += str);
        }

        void DataReceived(object sender, DataReceivedEventArgs e)
        {
            byte[] msg = e.Data.Take(128).ToArray();
            byte[] data = e.Data.Skip(128).ToArray();


            string msgStr = Encoding.ASCII.GetString(msg);

            string[] splitted = msgStr.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            Dictionary<string, string> headers = new Dictionary<string, string>();
            foreach (string s in splitted)
            {
                if (s.Contains(":"))
                {
                    headers.Add(s.Substring(0, s.IndexOf(":")), s.Substring(s.IndexOf(":") + 1));
                }
            }

            if (headers.ContainsKey("recieving serpent key"))
            {

                serpentKey =  serpent.Decrypt(data, serpentKey, 32, Mode.Standard, EncryptionMode.CBC);  
            }
            else if (headers.ContainsKey("recieving public key"))
            {

                int[] public_key = new int[data.Length/sizeof(int)];

                Buffer.BlockCopy(data, 0, public_key, 0, data.Length);

                ntru = new NTRUEncrypt(new PolynomMod_q_n(public_key.Take(public_key.Length - 3).ToArray(), public_key[public_key.Length - 3], public_key[public_key.Length - 2], public_key[public_key.Length - 1]) );


                
                byte[] symetricKey = ntru.encryption(serpentKey);


                int buffersize = 128;

                byte[] header = null;


                string headerStr = "asking for serpent key:" + " asking for serpent key." + "\r\n";
                header = new byte[buffersize];
                Array.Copy(Encoding.ASCII.GetBytes(headerStr), header, Encoding.ASCII.GetBytes(headerStr).Length);


                byte[] result = new byte[header.Length + symetricKey.Length];
                header.CopyTo(result, 0);
                symetricKey.CopyTo(result, header.Length);


                client.Send(result);
            }
            else
            {                
                int filesize = Convert.ToInt32(headers["Content-length"]);
                String filename = headers["Filename"];



                if (MessageBox.Show("Do you want to download file ... from ...?",
                    "Confirmation", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {

                    string ext = System.IO.Path.GetExtension(filename);

                    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    saveFileDialog1.Filter = "All files(*.*)|*" + ext;


                    FileStream fs;

                    while (true)
                    {

                        try
                        {
                            if (saveFileDialog1.ShowDialog() == false)
                                return;
                            string chooseFileName = saveFileDialog1.FileName;


                            fs = new FileStream(chooseFileName, FileMode.Create);
                        }
                        catch
                        {
                            continue;
                        }

                        break;
                    }

                    String str = $"[{e.IpPort}]: Recieved file - {filename} with size - {filesize}\n";

                    Dispatcher.Invoke(() => MyTextBlock.Text += str);


                    data = serpent.Decrypt(data, serpentKey, 32, Mode.Standard, EncryptionMode.CBC);

                    fs.Write(data, 0, data.Length);
                    fs.Close();
                }

            }


        }
    }
}
