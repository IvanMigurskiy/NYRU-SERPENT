﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace WpfApp4.Models
{
    public class SerpentCipher
    {
        private const int BlockSize = 16; 
        private const int DefaultKeySize = 32;
        private static readonly RandomNumberGenerator rng = RandomNumberGenerator.Create();


        public byte[] Encrypt(byte[] data, byte[] Key, int Rounds, Mode Mode, EncryptionMode EncrMode)
        {
            SerpentAlgorithm sa;

            var iv = new byte[BlockSize];
            rng.GetBytes(iv);
            int c = data.Length;
            while (c % BlockSize != 0)
                c++;
            byte[] result = new byte[c];

            sa = new SerpentStandardMode();
             

            var position = 0;
            var fragmentSize = 1024 * 1024 > data.Length ? data.Length : 1024 * 1024; 
            while (fragmentSize % BlockSize != 0)
                fragmentSize++;
            sa.Rounds = Rounds;
            sa.BlockSize = BlockSize;
            var previousBlock = Array.Empty<byte>();

            var expandedKey = sa.MakeKey(Key);


            do
            {
                var InputFileFragment = data.Skip(position).Take(fragmentSize).ToList();
                if (InputFileFragment.Count < fragmentSize)
                    for (int i = InputFileFragment.Count; i < fragmentSize; i++)
                        InputFileFragment.Add(0);
               var OutputFileFragment = new List<byte>();


                for (var i = 0; i < InputFileFragment.Count; i += BlockSize)
                {
                    
                    if (position == 0 && i == 0) 
                        previousBlock = iv;

                    byte[] plainText = new byte[BlockSize];
                    InputFileFragment.CopyTo(i, plainText, 0, plainText.Length);

                    var currBlock = plainText.XOR(previousBlock); 
                    var cipherText = sa.BlockEncrypt(currBlock, 0, expandedKey);
                    OutputFileFragment.AddRange(cipherText);
                    previousBlock = cipherText;
                    
                }

                Array.Copy(OutputFileFragment.ToArray(), 0, result, position, OutputFileFragment.Count);

                position += fragmentSize; 
                //var encryptionProgressChangedEventData = new EncryptionProgressChangedEventArgs(((int)((double)position / result.Length * 100.0)), ActionType.Encryption); 
                //OnEncryptionProgressChanging(encryptionProgressChangedEventData); 

            }
            while (position < data.Length); 



            var ivAndSalt = new byte[iv.Length];
            iv.CopyTo(ivAndSalt, 0);

            byte[] result2 = new byte[result.Length+ivAndSalt.Length];
            ivAndSalt.CopyTo(result2, 0);

            result.CopyTo(result2, ivAndSalt.Length);

            return result2;
        }





        public byte[] Decrypt(byte[]  data, byte[] Key, int Rounds, Mode Mode, EncryptionMode EncrMode)
        {
            SerpentAlgorithm sa;
            byte[] result = new byte[data.Length-BlockSize];
            sa = new SerpentStandardMode();
                   

            var position = 0;
            int fragmentSize = 1024 * 1024 > data.Length ? data.Length-BlockSize : 1024 * 1024; 
            sa.Rounds = Rounds;
            sa.BlockSize = BlockSize;

            byte[] iv = new byte[BlockSize];
            var previousBlock = Array.Empty<byte>();

            Array.Copy(data, 0, iv, 0, BlockSize);

           
            

            var expandedKey = sa.MakeKey(Key);


            position += BlockSize;
            
            do
            {
                var InputFileFragment = data.Skip(position).Take(fragmentSize).ToList();

                var OutputFileFragment = new List<byte>();

                for (var i = 0; i < InputFileFragment.Count; i += BlockSize)
                {
                    if (position-BlockSize == 0 && i == 0)
                        previousBlock = iv;
                    var cipherText = InputFileFragment.GetRange(i, BlockSize).ToArray();
                    var currBlock = sa.BlockDecrypt(cipherText, 0, expandedKey);
                    var plainText = currBlock.XOR(previousBlock);
                    OutputFileFragment.AddRange(plainText);
                    previousBlock = cipherText;                        
                }

                Array.Copy(OutputFileFragment.ToArray(), 0, result, position - BlockSize, OutputFileFragment.Count);


                position += fragmentSize; 
                //var encryptionProgressChangedEventData = new EncryptionProgressChangedEventArgs((int)((double)position / data.Length * 100.0), ActionType.Decryption); 
                //OnEncryptionProgressChanging(encryptionProgressChangedEventData); 

            }
            while (position < data.Length); 


            return result;
        }
        
        
        public static byte[] RandomizeKey()
        {
            var key = new byte[DefaultKeySize];
            rng.GetNonZeroBytes(key);
            return key;
        }

        public event EncryptionProgressChangedEventHandler EncryptionProgressChanged;

        protected virtual void OnEncryptionProgressChanging(EncryptionProgressChangedEventArgs e) 
        {
            EncryptionProgressChanged?.Invoke(this, e);
        }
    }

    public enum ActionType
    {
        Encryption,
        Decryption,
        ChangingText,
    }

    public enum Mode
    {
        Standard,
        BitSlice
    }

    public enum EncryptionMode
    {
        ECB,
        CBC
    }

    public enum KeyMode
    {
        Chars,
        Bytes
    }

    public class EncryptionProgressChangedEventArgs : EventArgs 
    {
        public int Progress { get; } 
        public ActionType ActionType { get; }

        public EncryptionProgressChangedEventArgs(int progress, ActionType actionType) 
        {
            Progress = progress;
            ActionType = actionType;
        }
    }

    public delegate void EncryptionProgressChangedEventHandler(object sender, EncryptionProgressChangedEventArgs e); 
    public static class ExtensionMethods
    {
        public static byte[] XOR(this byte[] buffer1, byte[] buffer2)
        {
            for (var i = 0; i < buffer1.Length; i++)
                buffer1[i] ^= buffer2[i];

            return buffer1;
        }
    }
}
